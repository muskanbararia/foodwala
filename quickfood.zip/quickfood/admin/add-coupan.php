<section id="section-3">
<form method="post" action="index.php">
                    <div class="row">
                    
                        <div class="col-md-6 col-sm-6 add_bottom_15">
                            <div class="indent_title_in">
                                <i class="icon_lock_alt"></i>
                                <h3>Add a new coupan</h3>
                                
                            </div>
                            <div class="wrapper_indent">
                                <div class="form-group">
                                    <label>Coupan Name</label>
                                    <input class="form-control" name="name" id="old_password" type="text">
                                </div>
                                <div class="form-group">
                                    <label>Type</label>
                                     <select name="type" class="form-control">
                                      <option value="percent">Percent</option>
                                      <option value="fixed">Fixed</option>
                                      
                                    </select> 
                                </div>
                                <div class="form-group">
                                    <label>Enter amount/% value</label>
                                    <input class="form-control" name="value" id="confirm_new_password" type="text">
                                </div>
                                <div class="form-group">
                                    <label>Valid on (Min amount)</label>
                                    <input class="form-control" name="valid" id="confirm_new_password" type="text">
                                </div>
                                 <input class="btn_1" type="submit" name = "c_submit" value="Add">
                            </div><!-- End wrapper_indent -->
                        </div>
                        
                        
                        
                    </div><!-- End row -->

                    <!-- End row -->
                    </div><!-- End wrapper_indent -->
                    
                </section>