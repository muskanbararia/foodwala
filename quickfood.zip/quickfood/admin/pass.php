<section id="section-4">

					<div class="row">
                    <form action="index.php" method="post">
						<div class="col-md-6 col-sm-6 add_bottom_15">
							<div class="indent_title_in">
								<i class="icon_lock_alt"></i>
								<h3>Change your password</h3>
								
							</div>
							<div class="wrapper_indent">
								<div class="form-group">
									<label>Old password</label>
									<input class="form-control" name="old_password" id="old_password" type="password">
								</div>
								<div class="form-group">
									<label>New password</label>
									<input class="form-control" name="new_password" id="new_password" type="password">
								</div>
								<div class="form-group">
									<label>Confirm new password</label>
									<input class="form-control" name="confirm_new_password" id="confirm_new_password" type="password">
								</div>
								 <input class="btn_1" type="submit" name = "p_submit" value="Add">
							</div><!-- End wrapper_indent -->
						</div>
						</div></section>