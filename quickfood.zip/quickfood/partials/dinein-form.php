<div class="form-group">
  <label>First name</label>
  <input type="text" class="form-control" id="firstname_order" name="firstname_order" placeholder="First name">
</div>
<div class="form-group">
  <label>Last name</label>
  <input type="text" class="form-control" id="lastname_order" name="lastname_order" placeholder="Last name">
</div>
<div class="form-group">
  <label>Telephone/mobile</label>
  <input type="text" id="tel_order" name="tel_order" class="form-control" placeholder="Telephone/mobile">
</div>
<div class="form-group">
  <label>Email</label>
  <input type="email" id="email_booking_2" name="email_order" class="form-control" placeholder="Your email">
</div>
<div class="form-group">
  <label>Your full address</label>
  <input type="text" id="address_order" name="address_order" class="form-control" placeholder=" Your full address">
</div>
<div class="row">
  <div class="col-md-6 col-sm-6">
    <div class="form-group">
      <label>City</label>
      <input type="text" id="city_order" name="city_order" class="form-control" placeholder="Your city">
    </div>
  </div>
  <div class="col-md-6 col-sm-6">
    <div class="form-group">
      <label>Postal code</label>
      <input type="text" id="pcode_oder" name="pcode_oder" class="form-control" placeholder=" Your postal code">
    </div>
  </div>
</div>
<hr>
<div class="row">
  <div class="col-md-6 col-sm-6">
    <div class="form-group">
      <label>Delivery Day</label>
      <select class="form-control" name="delivery_schedule_day" id="delivery_schedule_day">
        <option value="" selected>Select day</option>
        <option value="Today">Today</option>
        <option value="Tomorrow">Tomorrow</option>
      </select>
    </div>
  </div>
  <div class="col-md-6 col-sm-6">
    <div class="form-group">
      <label>Delivery time</label>
      <select class="form-control" name="delivery_schedule_time" id="delivery_schedule_time">
        <option value="" selected>Select time</option>
        <option value="11.30am">11.30am</option>
        <option value="11.45am">11.45am</option>
        <option value="12.15am">12.15am</option>
        <option value="12.30am">12.30am</option>
        <option value="12.45am">12.45am</option>
        <option value="01.00pm">01.00pm</option>
        <option value="01.15pm">01.15pm</option>
      </select>
    </div>
  </div>
</div>
<hr>
<div class="row">
  <div class="col-md-12">

      <label>Notes for the restaurant</label>
      <textarea class="form-control" style="height:150px" placeholder="Ex. Allergies, cash change..." name="notes" id="notes"></textarea>

  </div>
</div>